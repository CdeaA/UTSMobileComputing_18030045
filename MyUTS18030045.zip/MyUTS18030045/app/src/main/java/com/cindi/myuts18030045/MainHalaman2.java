package com.cindi.myuts18030045;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;



import android.content.Intent;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainHalaman2 extends AppCompatActivity {


// INSTANSIASI LAYOUT XML HALAMAN 2
    TextView nim,mhs,kelas;
    EditText txt_tgl,matkul,sks,sifatUjian,programStudi,pengampu;
    Button submit,reset;


    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.halaman2);

//        Instansiasi Variabel
        nim     = (TextView) findViewById(R.id.nim_mhs);
        mhs     = (TextView) findViewById(R.id.nama_mhs);
        kelas   = (TextView) findViewById(R.id.kelas_mhs);


        txt_tgl     = (EditText) findViewById(R.id.txt_tgl);
        matkul      = (EditText) findViewById(R.id.matkul);
        sks         = (EditText) findViewById(R.id.sks);
        sifatUjian  = (EditText) findViewById(R.id.sifat_ujian);
        programStudi    = (EditText) findViewById(R.id.program_studi);
        pengampu         = (EditText) findViewById(R.id.dosen_pengampu);


        submit = (Button) findViewById(R.id.btn_submit);
        reset = (Button) findViewById(R.id.btn_reset);


//      MENGAMBIL INTENT

        if(getIntent().getStringExtra("nimMhs") != null){
            String nimMhs = getIntent().getStringExtra("nimMhs");
            nim.setText("NIM : "  + nimMhs);
        }
        if(getIntent().getStringExtra("namaMhs") != null){
            String namaMhs = getIntent().getStringExtra("namaMhs");
            mhs.setText("NAMA : "+namaMhs);
        }
        if(getIntent().getStringExtra("kelasMhs") != null){
            String kelasMhs = getIntent().getStringExtra("kelasMhs");
            kelas.setText("Kelas : "+kelasMhs);
        }


//        MENGAMBIL TANGGAL DI KALENDER

        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR,year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
               updateCalender();
            }
        };


//        JIKA EDIT TEXT TGL DI KLIK MAKA TAMPILKAN CALENDER
        txt_tgl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(MainHalaman2.this,date,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


//       JIKA TOMBOL SUBMIT DI TEKAN KIRIM DATANYA


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String nimMhs = getIntent().getStringExtra("nimMhs");
                String namaMhs = getIntent().getStringExtra("namaMhs");
                String kelasMhs = getIntent().getStringExtra("kelasMhs");

                String tglUjian = txt_tgl.getText().toString();
                String mataKuliah = matkul.getText().toString();
                String sKs = sks.getText().toString();
                String sftUjian = sifatUjian.getText().toString();
                String prodi = programStudi.getText().toString();
                String dsn_pengampu = pengampu.getText().toString();


//               PANGGIL OBJEK INTENT KE HALAMAN 3
                Intent i = new Intent(MainHalaman2.this,MainHalaman3.class);

//                KIRIM DATANYA

                i.putExtra("namaMhs",namaMhs);
                i.putExtra("nimMhs",nimMhs);
                i.putExtra("kelasMhs",kelasMhs);

                i.putExtra("tgl",tglUjian);
                i.putExtra("matkul",mataKuliah);
                i.putExtra("sks",sKs);

                i.putExtra("sifatUjian",sftUjian);
                i.putExtra("prodi",prodi);
                i.putExtra("dsnPengampu",dsn_pengampu);


                startActivity(i);


//                AKHIRI DI HALAMAN 2 INI
                finish();



            }
        });


//      JIKA TOMBOL RESET DITEKAN KOSONGKAN ISIAN EDIT TEXT KESELURUHAN
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_tgl.setText("");
                matkul.setText("");
                sks.setText("");
                sifatUjian.setText("");
                programStudi.setText("");
                pengampu.setText("");
            }
        });

    }


//    FUNCTION UPDATE CALENDAR
    private void updateCalender(){

        String myFormat = "dd-MM-yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        txt_tgl.setText(sdf.format(myCalendar.getTime()));

    }


}