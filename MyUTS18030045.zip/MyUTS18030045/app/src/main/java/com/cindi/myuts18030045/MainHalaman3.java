package com.cindi.myuts18030045;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainHalaman3 extends AppCompatActivity {


    TextView judulProdi,namaMhs,nimMhs,
            kelasMhs,matkulMhs,sksMhs,dosenPengampu,sifatUjian,
            tglUjian;

    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.halaman3);


//        INSTANSIASI
        judulProdi       = (TextView) findViewById(R.id.program_studi);
        namaMhs          = (TextView) findViewById(R.id.namaMhs);
        nimMhs           = (TextView) findViewById(R.id.nimMhs);

        kelasMhs         = (TextView) findViewById(R.id.kelas);
        matkulMhs        = (TextView) findViewById(R.id.matkul);
        sksMhs           = (TextView) findViewById(R.id.sks);

        dosenPengampu   = (TextView) findViewById(R.id.dosenPengampu);
        tglUjian        = (TextView) findViewById(R.id.tgl);
        sifatUjian      = (TextView) findViewById(R.id.sifat_ujian);

        btnBack         = (Button) findViewById(R.id.btn_back);



//      JIKA ADA DATA YANG DI KIRMKAN KE HALAMAN INI MAKA TAMPILKAN SEMUA

        String nama_mhs = getIntent().getStringExtra("namaMhs");
        String nim_mhs = getIntent().getStringExtra("nimMhs");

        String kelas_mhs = getIntent().getStringExtra("kelasMhs");
        String tgl_ujian = getIntent(). getStringExtra("tgl");

        String mata_kuliah = getIntent().getStringExtra("matkul");
        String sks = getIntent().getStringExtra("sks");

        String sifat_ujian = getIntent().getStringExtra("sifatUjian");
        String prodi = getIntent().getStringExtra("prodi");

        String dosen_pengampu = getIntent().getStringExtra("dsnPengampu");


//       TAMPILKAN KE SELURUH HALAMAN TEXT VIEW
        judulProdi.setText("PROGRAM STUDI "+prodi);
        namaMhs.setText(nama_mhs);

        nimMhs.setText(nim_mhs);
        kelasMhs.setText(kelas_mhs);

        matkulMhs.setText(mata_kuliah);
        sksMhs.setText(sks);

        dosenPengampu.setText(dosen_pengampu);
        tglUjian.setText(tgl_ujian);

        sifatUjian.setText(sifat_ujian);





//      JIKA TOMBOL KEMBALI DI KLIK MAKA KEMBALIKAN KE HALAMAN UTAMA

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Pindahkan ke my actifity
                Intent i = new Intent(MainHalaman3.this,MainActivity.class);

                startActivity(i);
                finish();
            }
        });




    }

}