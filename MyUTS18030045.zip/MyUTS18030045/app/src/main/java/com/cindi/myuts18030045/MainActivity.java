package com.cindi.myuts18030045;


import android.content.Intent;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


//-----------------------------------------------------------

// ============ DOCUMENTATION BY Cindy Deariska(18030046) ===

// =========== Copyright @ com.cindy.18030046 ===============

//-----------------------------------------------------------


public class MainActivity extends AppCompatActivity {

    EditText nama_et,nim_et;
    Button btn_et;

    RadioGroup radio_grp;
    RadioButton kls_A, kls_B,radioButton;

    // ===== function pertama yang secara default di jalankan atau yang ditampilkan pertama  kali
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        HALAMAN YANG DIATUR IALAH ACTIVITY MAIN
        setContentView(R.layout.activity_main);

//     Instansiasi
        nama_et = (EditText) findViewById(R.id.nama_mahasiswa);
        nim_et = (EditText) findViewById(R.id.nim);
        btn_et = (Button) findViewById(R.id.input_data);
        radio_grp = (RadioGroup) findViewById(R.id.radio_grp);
        kls_A = (RadioButton) findViewById(R.id.kelas_A);
        kls_B = (RadioButton) findViewById(R.id.Kelas_B);

        btn_et.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String namaMhs = nama_et.getText().toString();
                String nimMhs = nim_et.getText().toString();

                int radioId = radio_grp.getCheckedRadioButtonId();
                radioButton = findViewById(radioId);

                String kelasMhs = radioButton.getText().toString();


                try {


                    if (nama_et == null || nim_et == null) {
//                      ERROR TOAST

                        Toast.makeText(getApplicationContext(), "Harap isi seluruhnya", Toast.LENGTH_LONG).show();
                    } else {


//                       MEMANGGIL OBJEK INTENT
                        Intent i = new Intent(MainActivity.this, MainHalaman2.class);


//                        KIRIMKAN DATA ISIAN KE HALAMAN 2
                        i.putExtra("namaMhs", namaMhs);
                        i.putExtra("nimMhs", nimMhs);
                        i.putExtra("kelasMhs", kelasMhs);

                        startActivity(i);

//                        GUNAKAN FINISH UNTUK MEMBERHENTIKAN AKSI DI HALAMAN MAIN ACTIVITY
                        finish();


                    }

                }catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this,"ERROR PLEASE TRY AGAIN !!",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


}